from litex.soc.cores.cpu.vexriscv_smp.core  import VexRiscvSMP
