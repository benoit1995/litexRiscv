from litex.soc.cores.cpu.lm32.core import LM32
