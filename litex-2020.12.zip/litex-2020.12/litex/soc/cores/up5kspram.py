# Retro-compatibility 2020-11-09, remove.
from litex.soc.cores.ram.lattice_ice40 import Up5kSPRAM
