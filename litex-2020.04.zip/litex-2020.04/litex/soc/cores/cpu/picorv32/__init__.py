from litex.soc.cores.cpu.picorv32.core import PicoRV32
