from litex.soc.cores.cpu.microwatt.core import Microwatt
