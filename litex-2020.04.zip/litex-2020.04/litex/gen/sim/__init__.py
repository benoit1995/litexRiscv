from litex.gen.sim.core import Simulator, run_simulation, passive
