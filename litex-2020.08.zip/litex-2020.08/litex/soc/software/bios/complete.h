#ifndef __COMPLETE_H__
#define __COMPLETE_H__

int complete(char *instr, char **outstr);

#endif
