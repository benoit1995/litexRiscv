#ifndef __MATH_H
#define __MATH_H

#ifdef __cplusplus
extern "C" {
#endif

#include "../fdlibm/fdlibm.h"

#ifdef __cplusplus
}
#endif

#endif /* __MATH_H */
