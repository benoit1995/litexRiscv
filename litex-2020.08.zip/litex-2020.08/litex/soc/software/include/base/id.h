#ifndef __ID_H
#define __ID_H

#ifdef __cplusplus
extern "C" {
#endif

#define IDENT_SIZE 256
void get_ident(char *ident);

#ifdef __cplusplus
}
#endif

#endif /* __ID_H */
