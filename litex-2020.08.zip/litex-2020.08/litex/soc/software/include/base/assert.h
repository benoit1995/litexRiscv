#ifndef __ASSERT_H
#define __ASSERT_H

#define assert(x)

#endif /* __ASSERT_H */
