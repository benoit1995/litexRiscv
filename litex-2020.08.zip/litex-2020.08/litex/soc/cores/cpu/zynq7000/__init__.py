from litex.soc.cores.cpu.zynq7000.core import Zynq7000
