from litex.soc.cores.cpu.blackparrot.core import BlackParrotRV64
