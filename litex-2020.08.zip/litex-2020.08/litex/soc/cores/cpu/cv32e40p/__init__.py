from litex.soc.cores.cpu.cv32e40p.core import CV32E40P
